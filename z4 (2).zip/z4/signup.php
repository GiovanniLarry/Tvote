<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $whatsapp = htmlspecialchars($_POST['whatsapp']);
    $country_code = htmlspecialchars($_POST['country_code']);
    $dob = htmlspecialchars($_POST['dob']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Database connection
    $servername = "localhost";
    $usernameDB = "root";
    $passwordDB = "";
    $dbname = "tvote";

    $conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the user already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR whatsapp = ?");
    $stmt->bind_param("ss", $email, $whatsapp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('User with this email or phone number already exists.'); window.history.back();</script>";
        exit;
    }

    // Insert new user into database
    $stmt = $conn->prepare("INSERT INTO users (username, email, whatsapp, country_code, dob, password, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssss", $username, $email, $whatsapp, $country_code, $dob, $password);

    if ($stmt->execute()) {
        // Store email and phone in session for later validation
        $_SESSION['signup_email'] = $email;
        $_SESSION['signup_phone'] = $whatsapp;

        echo "<script>alert('Signup successful!'); window.location.href = 'contact.html';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>
